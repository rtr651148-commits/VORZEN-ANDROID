VØRZEN — ANDROID APK BUILDER

Ini adalah proyek starter Android, bukan file APK jadi.

CARA BUILD DARI HP ANDROID:
1. Ekstrak ZIP ini.
2. Buat repository baru di GitHub melalui browser (github.com), beri nama vorzen-android.
3. Upload seluruh ISI folder proyek ke repository tersebut. Pastikan folder .github/workflows ikut ter-upload.
4. Buka tab Actions di repository dan aktifkan Actions bila diminta.
5. Jalankan workflow "Build VORZEN APK" lewat tombol Run workflow.
6. Tunggu sampai job selesai dengan tanda hijau.
7. Buka hasil run, cari bagian Artifacts, lalu unduh VORZEN-debug-APK.
8. Ekstrak file hasil unduhan untuk mendapatkan app-debug.apk.

CATATAN:
- Build memerlukan koneksi internet dan akun GitHub.
- APK debug cocok untuk uji coba pribadi; bukan rilis Play Store.
- Pembayaran, login, AI, dan backend belum aktif. Paket role hanya tampilan demo.
- Fitur tools dibatasi untuk diagnostik perangkat sendiri dan moderasi yang sah.
